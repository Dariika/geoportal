from django.shortcuts import render
from common.commands import CommandResponse, CommandView
from .serializers import DrawZoneSerializer
from common.models import VectorFeaturePO
from django.contrib.gis.geos import Polygon, Point
# from Laviny import calculate_Accuratov_path
import math

class DrawZone(CommandView):
    serializer_class = DrawZoneSerializer
    name="Рисует зону поражения"
    description = "Рисует зону поражения"
    alias = "Определить зону"

    def convert(self, distance_km, long):
        # радиус Земли
        R = 6371
        km_per_lat = 2*math.pi*R / 360
        km_per_long = 2*math.pi*math.cos(math.radians(abs(long)))*R / 360
        return distance_km / km_per_lat, distance_km / km_per_long
    
    def calculate_Accuratov_path(self, w, h):
        # k = [0.72, 0.73, 0.74, 0.75]
        L = 0.73 * h * (math.log10(w) + 1)
        return L
    
    def handler(self, validated_data):
        center = validated_data['point_start']
        rad = self.calculate_Accuratov_path(validated_data['w'], validated_data['h'])
        radius_lat, radius_long = self.convert(rad/1000, center[1])
        circle = Polygon.from_bbox((center[0] - radius_long, center[1] - radius_lat, center[0] + radius_long, center[1] + radius_lat))
        return CommandResponse([], [
            VectorFeaturePO({}, 
                            (circle))
        ], [])



