from rest_framework import serializers
from common import serializers as geo_serializers

class DrawZoneSerializer(serializers.Serializer):
    w = serializers.FloatField()
    h = serializers.IntegerField()
    point_start = geo_serializers.PointField()



    